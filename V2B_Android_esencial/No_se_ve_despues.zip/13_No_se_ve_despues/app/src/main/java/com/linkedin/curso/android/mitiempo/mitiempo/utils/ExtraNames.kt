package com.linkedin.curso.android.mitiempo.mitiempo.utils

class ExtraNames {
    companion object {
        val TEMPERATURA_INFO = "informacion_de_temperatura"
        val PRESION_ATMOS_INFO = "informacion_presion_atmosférica"
        val POSICION_USUARIO_INFO = "posicion_usuario"
    }
}