package com.linkedin.curso.android.mitiempo.mitiempo


import android.support.v7.app.AppCompatActivity

abstract class BaseActivity : AppCompatActivity() {
    abstract fun initViews()
}